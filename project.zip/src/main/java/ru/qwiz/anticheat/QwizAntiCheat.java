package ru.qwiz.anticheat;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.UUID;

public final class QwizAntiCheat extends JavaPlugin implements Listener, CommandExecutor {

    // Внутренняя база данных для хранения игровых метрик игроков
    private final HashMap<UUID, PlayerMetrics> playerData = new HashMap<>();

    @Override
    public void onEnable() {
        // Регистрация событий и команд при запуске сервера
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("qac") != null) {
            getCommand("qac").setExecutor(this);
        }
        getLogger().info("QwizAntiCheat успешно запущен и готов к защите сервера!");
    }

    @Override
    public void onDisable() {
        playerData.clear();
        getLogger().info("QwizAntiCheat выключен.");
    }

    /**
     * Класс-хранилище данных игрока (Векторы, Дистанция, Клики)
     */
    private static class PlayerMetrics {
        public double lastYaw = 0;
        public double lastPitch = 0;
        public int headViolations = 0;
        public int reachViolations = 0;
        public int clickViolations = 0;
        public int totalClicks = 0;
        public long lastClickReset = System.currentTimeMillis();
    }

    private PlayerMetrics getOrCreateMetrics(UUID uuid) {
        return playerData.computeIfAbsent(uuid, k -> new PlayerMetrics());
    }

    /**
     * МОДУЛЬ 1: Отслеживание резких разворотов головы (Aimbot / KillAura)
     */
    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        // Игнорируем игроков в креативе или наблюдателей
        if (player.getGameMode().name().equals("CREATIVE") || player.getGameMode().name().equals("SPECTATOR")) return;

        PlayerMetrics metrics = getOrCreateMetrics(player.getUniqueId());

        double currentYaw = event.getTo().getYaw();
        double currentPitch = event.getTo().getPitch();

        // Считаем дельту (разницу) изменения углов обзора
        double deltaYaw = Math.abs(currentYaw - metrics.lastYaw);
        double deltaPitch = Math.abs(currentPitch - metrics.lastPitch);

        // Если поворот головы мгновенный и неестественный (свойственно жестким читам)
        if (deltaYaw > 110.0 && deltaPitch > 45.0) {
            metrics.headViolations++;
        }

        metrics.lastYaw = currentYaw;
        metrics.lastPitch = currentPitch;
    }

    /**
     * МОДУЛЬ 2: Отслеживание дистанции ударов (Reach)
     */
    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) return;

        Player damager = (Player) event.getDamager();
        Entity damaged = event.getEntity();

        PlayerMetrics metrics = getOrCreateMetrics(damager.getUniqueId());

        // Вычисляем точное расстояние между локациями игрока и цели в 3D пространстве
        double distance = damager.getLocation().distance(damaged.getLocation());

        // В Minecraft легитимная дистанция удара редко превышает 3.5 - 3.8 блоков с учетом пинга
        double maxFairDistance = damager.isSprinting() ? 3.9 : 3.6;

        if (distance > maxFairDistance && distance < 7.0) {
            metrics.reachViolations++;
        }
    }

    /**
     * МОДУЛЬ 3: Отслеживание скорости кликов (AutoClicker / Macros)
     */
    @EventHandler
    public void onPlayerAnimation(PlayerAnimationEvent event) {
        if (event.getAnimationType() != PlayerAnimationType.ARM_SWING) return;

        Player player = event.getPlayer();
        PlayerMetrics metrics = getOrCreateMetrics(player.getUniqueId());

        long currentTime = System.currentTimeMillis();
        // Сбрасываем счетчик кликов каждую секунду
        if (currentTime - metrics.lastClickReset > 1000) {
            if (metrics.totalClicks > 22) { // Если кликов больше 22 в секунду — это макрос
                metrics.clickViolations++;
            }
            metrics.totalClicks = 0;
            metrics.lastClickReset = currentTime;
        }

        metrics.totalClicks++;
    }

    /**
     * ИИ-СКОРИНГ: Расчет финальной вероятности использования читов в процентах
     */
    private int calculateCheatPercentage(PlayerMetrics metrics) {
        int percentage = 0;

        // Вес нарушений движения головы (макс +40%)
        if (metrics.headViolations > 5) percentage += 40;
        else if (metrics.headViolations > 2) percentage += 20;

        // Вес нарушений дистанции атаки (макс +45%)
        if (metrics.reachViolations > 4) percentage += 45;
        else if (metrics.reachViolations > 1) percentage += 25;

        // Вес нарушений скорости кликов (макс +15%)
        if (metrics.clickViolations > 3) percentage += 15;
        else if (metrics.clickViolations > 0) percentage += 10;

        return Math.min(100, percentage);
    }

    /**
     * КОМАНДНЫЙ ИНТЕРФЕЙС И ВЫВОД МЕНЮ АДМИНИСТРАТОРА
     */
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("qwiz.admin")) {
            sender.sendMessage(ChatColor.RED + "У вас нет прав для использования QwizAntiCheat!");
            return true;
        }

        if (args.length > 0 && args[0].equalsIgnoreCase("menu")) {
            sender.sendMessage(ChatColor.DARK_GRAY + "================================================");
            sender.sendMessage(ChatColor.GOLD + "       🛡  QWIZ-AI ANTI-CHEAT : ИИ ПАНЕЛЬ  🛡");
            sender.sendMessage(ChatColor.DARK_GRAY + "================================================");
            sender.sendMessage(ChatColor.GRAY + " Игроков под наблюдением: " + ChatColor.GREEN + getServer().getOnlinePlayers().size());
            sender.sendMessage(ChatColor.DARK_GRAY + "------------------------------------------------");

            for (Player onlinePlayer : getServer().getOnlinePlayers()) {
                PlayerMetrics metrics = getOrCreateMetrics(onlinePlayer.getUniqueId());
                int probability = calculateCheatPercentage(metrics);

                String status;
                ChatColor color;
                
                // Градация статусов в зависимости от процента
                if (probability >= 75) {
                    status = "КРИТИЧЕСКИЙ (БАН)";
                    color = ChatColor.RED;
                } else if (probability >= 35) {
                    status = "ПОДОЗРИТЕЛЬНЫЙ";
                    color = ChatColor.GOLD;
                } else {
                    status = "ЧИСТО";
                    color = ChatColor.GREEN;
                }

                // Вывод детальной строчки по каждому игроку
                sender.sendMessage(ChatColor.WHITE + "• " + ChatColor.YELLOW + onlinePlayer.getName() + 
                        ChatColor.GRAY + " | Вероятность: " + color + probability + "%" + 
                        ChatColor.GRAY + " | " + color + status);
                
                // Дополнительный диагностический вывод для админа, если есть подозрения
                if (probability > 0) {
                    sender.sendMessage(ChatColor.DARK_GRAY + "  [Логи ИИ -> " +
                            " Повороты: " + metrics.headViolations + 
                            " | Дистанция: " + metrics.reachViolations + 
                            " | Кликер: " + metrics.clickViolations + " ]");
                }
            }
            sender.sendMessage(ChatColor.DARK_GRAY + "================================================");
            return true;
        }

        sender.sendMessage(ChatColor.RED + "Используйте: /qac menu для открытия панели администратора.");
        return true;
    }
}
